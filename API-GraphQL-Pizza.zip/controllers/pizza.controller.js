const { db } = require('../config/connection')

const pizzaResolver = {
    Query: {
        pizzas(root, {id}){
            if ( id == undefined) {
                return db.any('SELECT * FROM pizzas')
            } else {
                return db.one('SELECT * FROM pizzas WHERE piz_id = $1', [id])
            }
        }
    }
}

module.exports = pizzaResolver